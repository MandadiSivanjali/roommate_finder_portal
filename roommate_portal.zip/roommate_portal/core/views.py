from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from .forms import SignUpForm, ProfileForm, MessageForm
from .models import Profile, Message
from django.contrib.auth.models import User

def home(request):
    return render(request, 'home.html')
def logout(request):
    return render(request,'logout.html')

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Create empty profile
            Profile.objects.create(user=user)
            login(request, user)
            return redirect('profile')
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})

@login_required
def profile(request):
    profile, created = Profile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('matches')
    else:
        form = ProfileForm(instance=profile)

    info_complete = all([profile.college, profile.budget, profile.location, profile.about, profile.hobbies])

    return render(request, 'profile.html', {
        'form': form,
        'info_complete': info_complete
    })

@login_required
def matches_view(request):
    # All profiles except the logged-in user
    matches = Profile.objects.exclude(user=request.user)
    
    # Logged-in user's profile
    user_profile, created = Profile.objects.get_or_create(user=request.user)

    return render(request, 'matches.html', {
        'matches': matches,
        'user_profile': user_profile
    })
def matches(request):
    user_profile = Profile.objects.filter(user=request.user).first()
    profiles = Profile.objects.exclude(user=request.user)

    if not user_profile:
        return render(request, "matches.html", {"matches": []})

    filters = {}
    if user_profile.location:
        filters["location"] = user_profile.location
    if user_profile.budget:
        filters["budget__lte"] = user_profile.budget
    if user_profile.pref_gender and user_profile.pref_gender != "Anyone":
        filters["pref_gender"] = user_profile.pref_gender
    if user_profile.pref_schedule:
        filters["pref_schedule"] = user_profile.pref_schedule

    matches_list = profiles.filter(**filters) if filters else profiles

    return render(request, "matches.html", {"matches": matches_list})
@login_required
def chat(request, user_id):
    other_user = get_object_or_404(User, id=user_id)
    messages = Message.objects.filter(sender=request.user, receiver=other_user) | \
               Message.objects.filter(sender=other_user, receiver=request.user)
    messages = messages.order_by('timestamp')

    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.sender = request.user
            message.receiver = other_user
            message.save()
            return redirect('chat', user_id=other_user.id)
    else:
        form = MessageForm()

    return render(request, 'chat.html', {
        'other_user': other_user,
        'messages': messages,
        'form': form
    })
def chat_list(request):
    # Later you can filter chats for this user
    chats = []
    return render(request, "chat_list.html", {"chats": chats})