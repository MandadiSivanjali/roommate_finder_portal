from django.urls import path
from django.contrib.auth import views as auth_views
from core import views

urlpatterns = [
    path('', views.home, name='home'),
    path('signup/', views.signup, name='signup'),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', views.logout,name='logout'),
    path('profile/', views.profile, name='profile'),
    path('matches/', views.matches, name='matches'), 
    path('chat/<int:user_id>/', views.chat, name='chat'),
    path("chats/", views.chat_list, name="chat_list"),
]
